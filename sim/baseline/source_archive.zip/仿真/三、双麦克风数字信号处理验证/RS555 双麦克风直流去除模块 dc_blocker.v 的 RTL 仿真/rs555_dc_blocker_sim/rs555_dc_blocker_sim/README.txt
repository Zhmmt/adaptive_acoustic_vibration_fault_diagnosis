RS555 DC blocker behavioral verification - Vivado 2026.1

Source provenance:
  dc_blocker.v copied unchanged from the user's original
  PYNQ_Z2_RS555_AXI_IIC_FIXEDV6(3).zip / rtl/dc_blocker.v

1. Close behavioral simulation in Vivado.
2. Add dc_blocker.v to Design Sources, unless it is already there.
3. Add tb_dc_blocker.v to Simulation Sources.
4. Right-click tb_dc_blocker > Set as Top.
5. Run Simulation > Run Behavioral Simulation.
6. In Tcl Console enter: run all
7. Expected final marker (not a pre-recorded result): DC_BLOCKER_TEST_PASS

To capture waveform:
  File > Simulation Waveform > New Waveform Configuration
  Add /tb_dc_blocker/clk resetn in_valid din dout out_valid
  Set din and dout radix to Signed Decimal.
  If the signals show no waveform, enter:
      restart
      log_wave -r /*
      run all
  Click Zoom Fit. Save .wcfg, a real screenshot .png, and the complete sim log.

Coverage:
  synchronous reset, exact first-step response, DC steady-state decay,
  input-valid idle holding, signed alternating samples, full-scale swings,
  and reset-history clearing. A direct recurrence reference checks every cycle.

Limits:
  This is RTL behavioral verification and NOT a hardware measurement of
  microphone frequency response, ADC accuracy, PL timing closure, or PYNQ board operation.
