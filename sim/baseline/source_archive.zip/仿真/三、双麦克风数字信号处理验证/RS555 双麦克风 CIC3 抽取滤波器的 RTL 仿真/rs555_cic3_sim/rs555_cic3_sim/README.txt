RS555 CIC3 decimator XSim behavioural test (Vivado 2026.1)

Source: cic3_decimator.v extracted without modification from user's RS555 submission engineering archive.

1. Close current behavioural simulation.
2. Add cic3_decimator.v to Design Sources (if it is not already present).
3. Add tb_cic3_decimator.v to Simulation Sources.
4. Set tb_cic3_decimator as simulation top.
5. Run Behavioral Simulation, then enter "run all" in Tcl Console.
6. Expected SUCCESS marker: CIC3_DECIMATOR_TEST_PASS.
   This is an EXPECTED string, not a claim that the Vivado run was performed.
7. New waveform config: add clk, resetn, sample_valid, pdm_bit,
   dout and out_valid from tb_cic3_decimator; restart; log_wave -r /*; run all.
8. Save screenshot, console log, waveform configuration and both .v files.

Testbench parameters: R=8, W=40 (reduced from production default R=125).
PDM bits are mapped to +1/-1 just as in the original module.
The golden reference independently computes the full triple moving-sum FIR
convolution of the input sequence. Checks every decimated sample and each
out_valid strobe, input-valid gaps, output hold, startup and reset recovery.
It does not establish real microphone frequency response, dynamic range,
production R=125 precision, physical PDM clocking, or FPGA timing closure.

Caution: the module's out_valid is a registered one-cycle pulse. The testbench
checks after the nonblocking assignments have settled (#1 ns).
