#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
iverilog -g2012 -s tb_cic3_decimator -o cic3_sim.vvp cic3_decimator.v tb_cic3_decimator.v
vvp cic3_sim.vvp
