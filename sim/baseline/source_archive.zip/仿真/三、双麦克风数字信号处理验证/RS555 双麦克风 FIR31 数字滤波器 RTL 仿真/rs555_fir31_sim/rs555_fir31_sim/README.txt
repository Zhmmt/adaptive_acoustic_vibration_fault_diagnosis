RS555 FIR31 RTL simulation - Vivado 2026.1

Source: original user project PYNQ_Z2_RS555_AXI_IIC_FIXEDV6(3).zip / rtl/fir31.v
The RTL was copied unchanged.

Steps:
1. Close current simulation (File > Close Simulation).
2. Add fir31.v as Design Source (unless already present).
3. Add tb_fir31.v as Simulation Source.
4. Right-click tb_fir31 in Simulation Sources > Set as Top.
5. Run Behavioral Simulation; in Tcl Console type: run all
6. Expect final line FIR31_TEST_PASS (this is expected, not a claimed result).
7. Add clk, resetn, in_valid, din, dout, out_valid to a NEW wave config.
8. For din and dout choose Radix > Signed Decimal.
9. Save actual wave screenshot, wcfg, console log, and Testbench.

Reference method:
The testbench independently performs a 31-tap signed convolution using
integer coefficients, arithmetic >> 15, and output saturation to signed
16-bit. It compares each accepted sample with the DUT and checks the valid
pulse and output hold during gaps.
Tests: positive/negative impulses, idle, DC, alternating, extreme inputs,
deterministic mixed inputs, repeated reset and history clearing.

Limitations: RTL behavioral simulation only. This does not establish
physical audio-frequency response, timing closure at target frequency,
actual PDM hardware performance, or a complete dual-microphone pipeline.
