# RS555 audio integration RTL simulation

This package uses the five unmodified RTL files extracted from the uploaded `PYNQ_Z2_RS555_AXI_IIC_FIXEDV6(3).zip` project.

## Vivado 2026.1 procedure

1. Close the previous behavioral simulation.
2. Add all five `src/*.v` files to Design Sources. Skip files already present in your project.
3. Add `sim/tb_audio_integration.v` to Simulation Sources.
4. Set `tb_audio_integration` as the simulation top.
5. Run Behavioral Simulation; in the Tcl Console, enter `run all`.
6. A successful run prints `AUDIO_INTEGRATION_TEST_PASS` and no `Fatal` errors.

## Coverage

* PDM shared-line phasing (A inputs high, B inputs low)
* Stereo PCM valid pulses through CIC3, DC blocker and FIR31
* AXI Stream stereo packing `{pcm_b, pcm_a}`
* `TKEEP`, four-beat frame `TLAST`, `TVALID/TREADY` transfer, stall stability

## Important limits

* The test deliberately accelerates clocking and decimation: HALF_DIV=2, DECIM_R=8, CIC_SHIFT=0 and FRAME_SAMPLES=4 instead of production defaults. It is not an audio fidelity, production-clock timing or hardware test.
* The bench checks the wiring and frame handshake, not an independent end-to-end audio golden model. Independent module-level checks were done separately in earlier tests.
* The RTL has no input FIFO for PCM while `TREADY=0`; samples that arrive during backpressure may be dropped. This test does not claim lossless DMA capture under arbitrary stalls.
* This package has not been run in Vivado/XSim here. Check actual console output and retain the logs.

Suggested evidence: `audio_integration_sim.log`, `audio_integration_wave.png`, `audio_integration_wave.wcfg`.
