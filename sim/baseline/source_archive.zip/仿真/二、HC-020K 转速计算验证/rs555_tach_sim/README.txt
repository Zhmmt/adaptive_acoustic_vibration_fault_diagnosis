RS555 tach_rpm RTL simulation - Vivado 2026.1

File sources:
- tach_rpm.v: copied byte-for-byte from the user's RS555 submission src/rtl/tach_rpm.v
- tb_tach_rpm.v: dedicated testbench for this exact module

How to run:
1. Close current Vivado behavioral simulation.
2. Add tach_rpm.v under Design Sources (File > Add Sources).
3. Add tb_tach_rpm.v under Simulation Sources.
4. Right-click tb_tach_rpm and select Set as Top.
5. Run Behavioral Simulation; Tcl Console: run all
6. Expect six TACH_PASS lines, RESET_OUTPUT_PASS and TACH_RPM_TEST_PASS.

Measurement meaning:
Clock is scaled from 100 MHz to 100 kHz to accelerate the 1-second gate.
Input pulse rates remain 100/200/300/400/500 Hz; simulation has 100000
cycles per gate. A one-pulse gate quantization difference = 3 RPM, so the
comparison accepts +/-3 RPM. This validates pulse counting and scaling in
RTL, not final board hardware timing or physical sensor calibration.

Caution: pulse_seen in this RTL stays high after the first detected pulse
until reset. It is not a live-speed indicator.
