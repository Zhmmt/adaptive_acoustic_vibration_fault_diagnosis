RS555 HC-020K dynamic tachometer RTL simulation

Contents
- tach_rpm.v: unchanged tachometer RTL copied from the user's previous RS555 tach simulation package.
- tb_tach_rpm_dynamic.v: additional Verilog testbench. Top: tb_tach_rpm_dynamic.

Vivado 2026.1 workflow
1. In existing rs555_pwm_sim project, close the current simulation.
2. Keep the existing tach_rpm.v Design Source; do not add a duplicate copy.
3. Add ONLY tb_tach_rpm_dynamic.v as a Simulation Source.
4. In Simulation Sources, set tb_tach_rpm_dynamic as Top.
5. Run Behavioral Simulation; Tcl Console: run all.
6. A complete successful run ends in TACH_DYNAMIC_TEST_PASS.
7. In the new waveform config add clk, resetn, tach_in, rpm[15:0], pulse_seen.
8. If signals appear empty, run restart; log_wave -r /*; run all.
9. Change rpm Radix to Unsigned Decimal; save WCFG, screenshot and simulator log.

Coverage
- 100 Hz -> 500 Hz transition, expected 300 -> 1500 RPM.
- 500 Hz -> 200 Hz transition, expected 1500 -> 600 RPM.
- Input stops, RPM must return to zero after two measurement gates.
- 3 simulated-clock-wide glitches on a 100 Hz pattern: filtered out.
- Valid 40-cycle-wide 100 Hz pulses after glitches: recognized.
- Reset clears RPM and pulse_seen; measurement recovers afterward.

Important test limits
- CLK_HZ_SIM=100000 with 10 ns simulated clock: the gate is 100000 simulated clock cycles, not 1 real second in the simulation timeline.
- The DUT measures in one-gate windows. Checks allow a two-gate stabilization delay and +/-3 RPM (one pulse quantization at PPR=20).
- The glitch test checks 3-clock pulses vs the RTL's 8-clock filter; it is not proof of robustness against analog noise or metastability on the board.
- pulse_seen is sticky in this RTL (stays high after the first detected pulse until reset); it is not a 'currently rotating' indication.
- This is behavioral simulation only, not a real HC-020K hardware measurement.
